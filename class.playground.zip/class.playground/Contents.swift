// object oriented






import UIKit


class Person{
    
    var name : String
    var age : Int
    init(name: String,age: Int) {
       self.name = name
        self.age = age
    }
    func greeting(){
        print("your name is \(self.name) and your age is \(self.age)")
    }

}

var personal = Person(name: "mohammed",age: 21)

personal.name
personal.age
personal.greeting()
