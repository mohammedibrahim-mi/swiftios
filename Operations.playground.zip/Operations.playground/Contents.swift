//: Playground - noun: a place where people can play



var str = "Hello, playground"

let (score, life) = (100.0, 3.0)
print(score, life)

var bonus = score / life
bonus += 1
print(bonus)


let highScore = 100
var myScore = 101

// Comparision operators
//  ==
//  !=
//  >
//  <
//  >=


// If else code block section
if myScore != highScore {
    print("Congrtas on highscore")
} else {
    print("Sorry, try again for highscore")
}







