//: Playground - noun: a place where people can play



var str = "Hello, playground"
str = "Hello swift"

var notStr = "Batman"
notStr = "Hulk"

let accountNumber = "6767667"

let fruitNameThatIwant = "apple"


var loginAttempts: Int = 5

print(loginAttempts)

var myInt = 400
var myDouble = 400.18
var myString = "This is something"
var myBoolean = false

var player1, player2, player3: Int
player1 = 2
player2 = 5

var player5 = "6"
var player6 = "6"


player6 + player5

print("Value of player1 is: \(player1)")

var myNewString =
"""
this"s is
a String
with Multiline
string
"""
print(myNewString)

// add smiley as string
let smile = "😃"
print(smile)

// TODO: decalre a function to call values from database





